var categories = <String>[
  'All',
  'Action',
  'Comedy',
  'Romance',
  'Slomance',
  'Slomance'
];
