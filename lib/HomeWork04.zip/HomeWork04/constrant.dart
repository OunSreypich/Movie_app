import 'package:flutter/material.dart';

const kButtonPrimaryColor = Color(0xffe00f33);
const kBackgroundColor = Color(0xff070420);

const kShadowColor = Color(0xff26233e);

const kPrimaryColor = Color(0xFFfe7f3c);
